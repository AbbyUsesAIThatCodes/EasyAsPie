@echo off
cd /d "%~dp0"
echo Open http://127.0.0.1:4200 in your browser. Keep this window open.
node serve-review.mjs . 4200
pause

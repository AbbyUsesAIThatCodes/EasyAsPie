@echo off
cd /d "%~dp0"
start "" http://127.0.0.1:4190
node serve-review.mjs . 4190
pause
